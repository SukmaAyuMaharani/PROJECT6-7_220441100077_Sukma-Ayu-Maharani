<?php
function kalkulator($bil1, $bil2, $operator) {
  switch ($operator) {
    case "+":
      return $bil1 + $bil2;
    case "-":
      return $bil1 - $bil2;
    case "*":
      return $bil1 * $bil2;
    case "/":
      if ($bil2 != 0) {
        return $bil1 / $bil2;
      } else {
        return "Error: Tidak dapat melakukan pembagian dengan nol";
      }
  }
}
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Kalkulator Sederhana</title>
    <link rel="stylesheet" href="kal.css">
  </head>
  <body>
    <div class="calculator">
      <h1>KALKULATOR SEDERHANA</h1>

      <?php
      if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $bil1 = $_POST["bil1"];
        $bil2 = $_POST["bil2"];
        $operator = $_POST["operator"];
        $result = kalkulator($bil1, $bil2, $operator);

        if (is_string($result)) {
          echo "<p class='error'>$result</p>";
        } else {
          echo "<p class='result'>$bil1 $operator $bil2 = $result</p>";
        }
      }
      ?>
    <div class>
    <form method="post">
        <input type="number" name="bil1" placeholder="Masukkan angka pertama" required>
    </div>
      
        <select name="operator" required>
          <option value="+">+</option>
          <option value="-">-</option>
          <option value="*">*</option>
          <option value="/">/</option>
        </select>
        <input type="number" name="bil2" placeholder="Masukkan angka kedua" required>
        <input type="submit" value="Hitung">
      </form>
    </div>
  </body>
</html>

